<?php

namespace Pusher\WordPress;

use Exception;

class InstallFailed extends Exception
{
}
